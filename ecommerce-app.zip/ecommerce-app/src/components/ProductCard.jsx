import React from "react";
import { Button, Card } from "react-bootstrap";

const money = (amount) => new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR", maximumFractionDigits: 0
}).format(amount);

export default function ProductCard({ product, onAddToCart }) {
  return (
    <Card className="product-card h-100">
      <div className="product-image-wrap">
        {product.tag && <span className="product-tag">{product.tag}</span>}
        <Card.Img variant="top" src={product.image} alt={product.name} className="product-image"
          onError={(event) => { event.currentTarget.src = "https://placehold.co/800x600/f0f1f7/565b70?text=ShopZone"; }} />
      </div>
      <Card.Body className="d-flex flex-column p-3 p-md-4">
        <div className="product-category">{product.category}</div>
        <Card.Title className="product-title">{product.name}</Card.Title>
        <div className="d-flex justify-content-between align-items-center mt-auto pt-3">
          <strong className="product-price">{money(product.price)}</strong>
          <Button className="add-button" onClick={() => onAddToCart(product)}>Add to cart <span aria-hidden="true">+</span></Button>
        </div>
      </Card.Body>
    </Card>
  );
}