import React from "react";
import { Badge, Container, Nav, Navbar } from "react-bootstrap";

export default function NavigationBar({ cartCount, onCartClick }) {
  return (
    <Navbar bg="white" expand="lg" sticky="top" className="shop-navbar">
      <Container>
        <Navbar.Brand href="#home" className="brand-mark"><span>✦</span> ShopZone</Navbar.Brand>
        <Navbar.Toggle aria-controls="shop-navigation" />
        <Navbar.Collapse id="shop-navigation">
          <Nav className="ms-auto align-items-lg-center gap-lg-3">
            <Nav.Link href="#home">Home</Nav.Link>
            <Nav.Link href="#products">Products</Nav.Link>
            <button className="cart-nav-button" onClick={onCartClick} aria-label={`Open cart with ${cartCount} items`}>
              <span aria-hidden="true">🛍</span> Cart <Badge bg="dark" pill>{cartCount}</Badge>
            </button>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}