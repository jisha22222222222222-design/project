import React from "react";
import { Button, Offcanvas } from "react-bootstrap";

const money = (amount) => new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR", maximumFractionDigits: 0
}).format(amount);

export default function Cart({ show, onClose, items, onRemove, onIncrease, onDecrease }) {
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  return (
    <Offcanvas show={show} onHide={onClose} placement="end" className="cart-drawer">
      <Offcanvas.Header closeButton>
        <Offcanvas.Title>Your shopping bag ({items.reduce((n, x) => n + x.quantity, 0)})</Offcanvas.Title>
      </Offcanvas.Header>
      <Offcanvas.Body className="d-flex flex-column">
        {items.length === 0 ? (
          <div className="empty-cart"><div>🛍️</div><h5>Your cart is empty</h5><p>Explore the collection and add something you love.</p><Button className="add-button" onClick={onClose}>Continue shopping</Button></div>
        ) : (
          <>
            <div className="cart-items">
              {items.map(item => (
                <div className="cart-line" key={item.id}>
                  <img src={item.image} alt="" />
                  <div className="cart-line-info">
                    <strong>{item.name}</strong>
                    <span>{money(item.price)}</span>
                    <div className="quantity-control">
                      <button onClick={() => onDecrease(item.id)} aria-label={`Decrease ${item.name} quantity`}>−</button>
                      <span>{item.quantity}</span>
                      <button onClick={() => onIncrease(item.id)} aria-label={`Increase ${item.name} quantity`}>+</button>
                      <button className="remove-link" onClick={() => onRemove(item.id)}>Remove</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="cart-summary mt-auto">
              <div className="d-flex justify-content-between mb-2"><span>Subtotal</span><strong>{money(total)}</strong></div>
              <small>Shipping and taxes are calculated at checkout.</small>
              <Button className="checkout-button w-100 mt-3" onClick={() => window.alert("This is a frontend demo. Checkout is not connected to payments.")}>Continue to checkout</Button>
            </div>
          </>
        )}
      </Offcanvas.Body>
    </Offcanvas>
  );
}