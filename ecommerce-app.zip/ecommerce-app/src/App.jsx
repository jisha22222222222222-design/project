import React, { useMemo, useState } from "react";
import { Button, Container, Form } from "react-bootstrap";
import NavigationBar from "./components/NavigationBar.jsx";
import ProductCard from "./components/ProductCard.jsx";
import Cart from "./components/Cart.jsx";
import products from "./products.js";
import "./App.css";

export default function App() {
  const [cartItems, setCartItems] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");

  const categories = ["All", ...new Set(products.map(product => product.category))];
  const visibleProducts = useMemo(() => products.filter(product => {
    const matchesCategory = category === "All" || product.category === category;
    const matchesSearch = product.name.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  }), [category, search]);

  const addToCart = (product) => {
    setCartItems(current => {
      const existing = current.find(item => item.id === product.id);
      return existing
        ? current.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...current, { ...product, quantity: 1 }];
    });
    setShowCart(true);
  };

  const removeFromCart = (id) => setCartItems(current => current.filter(item => item.id !== id));
  const increaseQuantity = (id) => setCartItems(current => current.map(item => item.id === id ? { ...item, quantity: item.quantity + 1 } : item));
  const decreaseQuantity = (id) => setCartItems(current => current.map(item => item.id === id ? { ...item, quantity: Math.max(1, item.quantity - 1) } : item));
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      <NavigationBar cartCount={cartCount} onCartClick={() => setShowCart(true)} />
      <main>
        <section className="hero-section" id="home">
          <Container>
            <div className="hero-copy">
              <span className="eyebrow">THE EVERYDAY EDIT</span>
              <h1>Good finds.<br /><em>Great feeling.</em></h1>
              <p>Thoughtful picks for work, play, and everything in between.</p>
              <Button href="#products" className="hero-button">Explore collection <span>→</span></Button>
            </div>
            <div className="hero-orbit orbit-one"></div>
            <div className="hero-orbit orbit-two"></div>
            <div className="hero-sticker">CURATED<br />FOR YOU ✦</div>
          </Container>
        </section>

        <Container className="shop-content" id="products">
          <div className="section-heading">
            <div><span className="eyebrow">FIND YOUR NEXT FAVORITE</span><h2>Shop the collection</h2></div>
            <span className="result-count">{visibleProducts.length} products</span>
          </div>

          <div className="shop-tools">
            <div className="category-list" aria-label="Filter by category">
              {categories.map(item => <button key={item} className={category === item ? "category-chip active" : "category-chip"} onClick={() => setCategory(item)}>{item}</button>)}
            </div>
            <Form.Control className="search-input" type="search" placeholder="Search products..." value={search} onChange={event => setSearch(event.target.value)} aria-label="Search products" />
          </div>

          <div className="product-grid">
            {visibleProducts.map(product => <ProductCard key={product.id} product={product} onAddToCart={addToCart} />)}
          </div>
          {visibleProducts.length === 0 && <div className="no-results">No products found. Try another search.</div>}
        </Container>
      </main>

      <footer className="site-footer"><Container><span className="brand-mark"><span>✦</span> ShopZone</span><span>Demo eCommerce storefront · Built with React & React-Bootstrap</span><span>© 2026 ShopZone</span></Container></footer>
      <Cart show={showCart} onClose={() => setShowCart(false)} items={cartItems} onRemove={removeFromCart} onIncrease={increaseQuantity} onDecrease={decreaseQuantity} />
    </>
  );
}