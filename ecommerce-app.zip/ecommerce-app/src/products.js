const products = [
  { id: 1, name: "Studio Wireless Headphones", price: 2499, category: "Electronics", image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=900&auto=format&fit=crop&q=80", tag: "Bestseller" },
  { id: 2, name: "Minimal Smart Watch", price: 3299, category: "Electronics", image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=900&auto=format&fit=crop&q=80", tag: "Popular" },
  { id: 3, name: "Everyday Running Shoes", price: 2199, category: "Fashion", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900&auto=format&fit=crop&q=80", tag: "New" },
  { id: 4, name: "Urban Travel Backpack", price: 1499, category: "Accessories", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=900&auto=format&fit=crop&q=80", tag: "" },
  { id: 5, name: "Compact Digital Camera", price: 18999, category: "Electronics", image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=900&auto=format&fit=crop&q=80", tag: "Featured" },
  { id: 6, name: "Classic Sunglasses", price: 999, category: "Fashion", image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=900&auto=format&fit=crop&q=80", tag: "" },
  { id: 7, name: "Ceramic Coffee Mug", price: 499, category: "Home", image: "https://images.unsplash.com/photo-1514228742587-6b1558f2023d?w=900&auto=format&fit=crop&q=80", tag: "" },
  { id: 8, name: "Desk Workspace Lamp", price: 1299, category: "Home", image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=900&auto=format&fit=crop&q=80", tag: "" }
];
export default products;